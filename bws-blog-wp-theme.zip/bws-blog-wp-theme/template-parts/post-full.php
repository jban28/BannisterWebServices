<div class="post">
  <h1 class="page-title"><?php the_title();?>
  <?php get_template_part('template-parts/post-header');?>
  <p>
  <?php echo get_the_content();?>
  </p>
</div>