<?php wp_body_open(); ?>
<?php get_header()?>
<main>
  <div class="error">Error 404. Page not found. <a href="/">Return to home</a></div>
</main>
<?php get_footer() ?>