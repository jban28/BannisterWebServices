    <div class="footer">
      <a href="https://www.bannisterwebservices.co.uk"><img height="100px" src="https://www.bannisterwebservices.co.uk/brand/logo.svg"/></a>
    </div>
  </body>
</html>